<html>
<form action ='auth.php' method='POST'>
	Username:<input type='text' name='username' required><br>
	Password:<input type='password' name='password' required><br>
	<input type='submit' value='Log In'>
</form>
<p> <a href='register.php'>Sign up</a> 
</html>

